package com.fti.santi;
public interface Jenis {
	public String getName();
    public void setName(String name);
    public void play();
}

